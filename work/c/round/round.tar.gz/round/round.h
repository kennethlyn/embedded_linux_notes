#ifndef ROUND_H
#define ROUND_H

double circle(double r);
double area(double r);
double volume(double r);


#endif // ROUND_H

