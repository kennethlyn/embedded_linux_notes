#include <math.h>

double area(double r)
{
	return M_PI * r * r;
}

