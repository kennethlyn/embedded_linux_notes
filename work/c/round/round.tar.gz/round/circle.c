#include <math.h>

double circle(double r)
{
	return M_PI * r * 2.0;
}

