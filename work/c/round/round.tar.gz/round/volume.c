#include <math.h>

double volume(double r)
{
	return M_PI * pow(r, 3.0) 
				* 4.0 / 3.0;
}

